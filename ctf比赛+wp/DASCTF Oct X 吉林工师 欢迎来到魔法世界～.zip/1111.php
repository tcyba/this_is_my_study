<?php
highlight_file('index.php');

extract($_GET);
error_reporting(0);
function String2Array($data)
{
    if($data == '') return array();
    @eval("\$array = $data;");
    return $array;
}


if(is_array($attrid) && is_array($attrvalue))
{
    $attrstr .= 'array(';
    $attrids = count($attrid);
    for($i=0; $i<$attrids; $i++)
    {
        $attrstr .= '"'.intval($attrid[$i]).'"=>'.'"'.$attrvalue[$i].'"';
        if($i < $attrids-1)
        {
            $attrstr .= ',';
        }
    }
    $attrstr .= ');';
}

String2Array($attrstr);
