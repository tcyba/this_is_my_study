package spring_shiro_550.demo.service;

import spring_shiro_550.demo.entity.UserInfo;

import java.util.List;

public interface UserInfoService {
    public UserInfo findByUsername(String username);
    public List<UserInfo> findAllUser();
}
