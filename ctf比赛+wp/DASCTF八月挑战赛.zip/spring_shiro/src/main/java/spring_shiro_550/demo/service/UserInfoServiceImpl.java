package spring_shiro_550.demo.service;

import org.springframework.stereotype.Service;
import spring_shiro_550.demo.dao.UserInfoDao;
import spring_shiro_550.demo.entity.UserInfo;

import javax.annotation.Resource;
import java.util.List;

@Service
public class UserInfoServiceImpl implements UserInfoService {

    @Resource
    UserInfoDao userInfoDao;

    public UserInfo findByUsername(String username) {
        return userInfoDao.findByUsername(username);
    }

    @Override
    public List<UserInfo> findAllUser() {
        return userInfoDao.findAll();
    }
}
