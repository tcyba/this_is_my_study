package spring_shiro_550.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import spring_shiro_550.demo.entity.UserInfo;

import java.util.List;


public interface UserInfoDao extends JpaRepository<UserInfo, Long> {
    public UserInfo findByUsername(String username);
    public List<UserInfo> findAll();
}
