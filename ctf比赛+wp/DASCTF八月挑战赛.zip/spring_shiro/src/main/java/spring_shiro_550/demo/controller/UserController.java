package spring_shiro_550.demo.controller;

import com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl;
import org.apache.catalina.security.SecurityUtil;
import org.apache.coyote.http11.Http11InputBuffer;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import spring_shiro_550.demo.entity.UserInfo;
import spring_shiro_550.demo.service.UserInfoService;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashSet;
import java.util.List;

@RestController
public class UserController {
    @Resource
    UserInfoService userInfoService;
    @GetMapping("/listAllUser")
    @RequiresPermissions("admin:listAll")
    public List<UserInfo> findUserInfoByUsername() {
        List<UserInfo> u = userInfoService.findAllUser();
        return u;
    }
    @GetMapping("/userList")
    @RequiresPermissions("admin:listByName")
    public UserInfo findUserInfoByUsername(@RequestParam String username) {
        UserInfo u = userInfoService.findByUsername(username);
        return u;
    }

    @GetMapping("/myInfo")
    @RequiresPermissions("user:showMyInfo")
    public UserInfo showMyInfo() {
        UserInfo userInfo = (UserInfo) SecurityUtils.getSubject().getPrincipal();

        UserInfo u = userInfoService.findByUsername(userInfo.getUsername());
        return u;
    }
}
