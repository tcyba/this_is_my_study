<?php
$target = 'http://127.0.0.1/admin/auth.php';
$data = "salt=mochu7";
$headers = array(
    'Header1: Values',
    'Header2: Values2'
);
var_dump($o = new SoapClient(null,array('location'=>$target,'user_agent'=>"testAgent\r\nContent-Type: application/x-www-form-urlencoded\r\n".join("\r\n",$headers)."\r\nContent-Length: ".(string)strlen($data)."\r\n\r\n".$data,'uri'=>'abc')));