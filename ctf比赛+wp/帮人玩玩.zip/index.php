<?php
class create_treehole{
    public $path;
    public $realpath = "";
    public $complaint = "";
    public $test;
    function __construct($path,$complaint){
        $this->complaint = $complaint;
        $this->path = $path;
        $this->realpath = "";
    }
    function make(){
           /**/
    }
    function back(){
        echo "Your worries are saved in ".$this->realpath."</br>";
    }
    function create_name($str){
        $salt='';
        for ($i = 0; $i < 10; $i++){
            $salt .= chr(mt_rand(33,126));
        }
        $str = "./treehole/".md5($str.$salt).".txt";
        return $str;
    }
    function __destruct(){
        if($this->test!=NULL){
            $this->test->back();
        }
    }

}
