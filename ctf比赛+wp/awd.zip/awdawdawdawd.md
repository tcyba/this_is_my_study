



打包

```
tar -zcvf /var/www/html/web.tar.gz  /var/www/html/*
```





```
pass=164408830a5e3b401797f6650275cd48&cmd=print_r%28%27shifumenqingyidianbiedadetaihen%27%29%3B
```





