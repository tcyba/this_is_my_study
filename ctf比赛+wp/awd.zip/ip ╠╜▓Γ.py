#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/10/29 9:34
# @Author  : upload
# @File    : ip 探测.py
# @Software: PyCharm

import requests

# #wb1
# for i in range(1,48):
#     url = "http://4.4.{}".format(i)+".100:80/"
#     try:
#         r = requests.get(url,timeout=1)
#         print(url)
#         if r.status_code == 200:
#             with open('web1ip.txt', 'w') as f:
#                 f.write(url)
#
#     except:
#         continue

#wb2
for i in range(1,255):
    ip = "http://47.94.0.{}".format(i)
    try:
        r = requests.get(ip,timeout=1,allow_redirects=False)
        if r.status_code == 200  or r.status_code == 302:
            print(ip)
            with open('web2ip.txt', 'a') as f:
                f.write(ip+'\n')

    except:
        continue

