<?php
namespace ctrl;

use model\visits;

class visit
{
    //调用访问数据并JSON输出
	public static function jsonList(){
		visits::insertData(); //用户访问记录 写入记数
		$result = visits::findData();
		exit(json_encode($result));
    }
}