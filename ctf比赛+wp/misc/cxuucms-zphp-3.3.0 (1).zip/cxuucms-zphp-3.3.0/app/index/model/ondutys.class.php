<?php
namespace model;

class ondutys
{
   //关联查找一条数据
   public static function findData()
   {
         $db = \ext\db::Init();
         return $db->table('onduty')->where('DATEDIFF(ondutytime,NOW()) = 0')->cache(20000)->find();
   }

}
