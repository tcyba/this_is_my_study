<?php

namespace model;

use root\base\model;

class notices extends model
{
    //查找一条数据
    public function findData()
    {
        $db = $this->db();
        $where['id'] = $_GET['id'];
        return $db->table('notices')->where($where)->find();
    }
    //查询列表  后台首页调用
    public function selectData($limit)
    {
        $db = $this->db();
        $where['status'] = 1;
        return $db->table('notices')->where($where)->limit($limit)->cache(600)->Order('id DESC')->select();
    }

    //添加数据
    public function insertData()
    {
        if (empty($_POST['title']))
        return ['status' => 0, 'msg' => '请填写必要数据'];
        $db = $this->db('notices');
        $data = [
            'title' => varFilter($_POST['title']),
            'img' => varFilter($_POST['img']),
            'content' => varFilter($_POST['content']),
            'time' => date('Y-m-d H:i:s', time()),
            'status' => $_POST['status'],
        ];
        $re_key = $db->insert($data);
        if ($re_key) {
            //写入日志
            insertSqlLog("添加公告信息 ID：" . $re_key);

            return ['key' => $re_key, 'status' => 1, 'msg' => '添加成功'];
        } else {
            return ['status' => 0, 'msg' => '数据错误！添加失败'];
        }
    }
    //更新数据
    public function updateData()
    {
        if (empty($_POST['title']))
             return ['status' => 0, 'msg' => '请填写必要数据'];
        $db = $this->db();
        $where['id'] = $_POST['id'];
        $data = [
            'title' => varFilter($_POST['title']),
            'img' => varFilter($_POST['img']),
            'content' => varFilter($_POST['content']),
            'status' => $_POST['status'],
            'time' => date('Y-m-d H:i:s', time()),
        ];
        $re_key = $db->table('notices')->Where($where)->Update($data);
        if ($re_key) {
            //写入日志
            insertSqlLog("修改公告信息 ID：" . $_POST['id']);

            return ['status' => 1, 'msg' => '修改成功'];
        } else {
            return ['status' => 0, 'msg' => '数据没有变化'];
        }
    }

    //删除一条数据
    public function deleteOneData()
    {
        $db = $this->db();
        $where['id'] = $_POST['id'];
        //写入日志
        insertSqlLog("删除公告信息 ID：" . $_POST['id']);

        return $db->table('notices')->where($where)->Delete();
    }

    //设置状态
    public function switchStatus()
    {
        $db = $this->db();
        $where['id'] = $_POST['id'];
        $data = [
            'status' => $_POST['status']
        ];
        //写入日志
        insertSqlLog("切换公告信息状态 ID：" . $_POST['id']);
        return $db->table('notices')->where($where)->Update($data);
    }

    //获取数据并分页
    public function jsonPageSelect()
    {
        $db = $this->db();
        $p = intval($_GET['page'] ?? 0) ?: 1;
        $num = intval($_GET['limit'] ?? 0) ?: 15;

        $page = ['num' => $num, 'p' => $p, 'return' => true];
        $result['data'] = $db->table('notices')->Page($page)->order('id DESC')->select();
        $result['page'] = $db->getPage();
        return $result;
    }
}
