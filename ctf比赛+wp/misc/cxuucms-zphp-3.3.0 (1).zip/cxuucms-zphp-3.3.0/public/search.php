<?php
define('APP_NAME', 'search'); /*定义应用目录名称*/
require '../core/core.php'; /*加载框架，升级框架时需要修改此处版本号的目录*/
AppRun(__FILE__);
