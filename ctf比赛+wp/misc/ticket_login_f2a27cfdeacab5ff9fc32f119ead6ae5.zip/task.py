#!/usr/bin/env python3
import os
import time
import signal
import string
import hashlib
import marshal
from random import SystemRandom

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import hashes, hmac

from secret import flag


random = SystemRandom()

enc_key = os.urandom(16)
mac_key = os.urandom(20)

nonce_set = set()


def pad(pt):
    pad_length = 16 - len(pt)%16
    pt += bytes([pad_length]) * pad_length
    return pt

def unpad(ct):
    pad_length = ct[-1]
    if pad(ct[:-pad_length]) == ct:
        return ct[:-pad_length]
    else:
        return None

def proof_of_work():
    proof = ''.join([random.choice(string.ascii_letters+string.digits) for _ in range(20)])
    digest = hashlib.sha256(proof.encode()).hexdigest()
    print("sha256(XXXX+%s) == %s" % (proof[4:],digest))
    x = input('Give me XXXX: ')
    if len(x) != 4 or hashlib.sha256((x + proof[4:]).encode()).hexdigest() != digest:
        return False
    return True

def gen_ticket(name):
    if name == "admin":
        auth_level = 1
    else:
        auth_level = 0

    auth_data = {
        "auth_level": auth_level,
        "name": name,
        "timestamp": int(time.time()),
        "nonce": random.getrandbits(32)
    }
    data = marshal.dumps(auth_data)

    iv = os.urandom(16)
    aes = Cipher(algorithms.AES(enc_key), modes.CBC(iv))
    encryptor = aes.encryptor()
    cipher = encryptor.update(pad(data)) + encryptor.finalize()

    h = hmac.HMAC(mac_key, hashes.SHA256())
    h.update(cipher)
    mac = h.finalize()

    ticket = iv + cipher + mac
    return ticket, auth_data["nonce"]

def register():
    name = input("your name: ")
    if not 4 < len(name) < 64:
        print("invalid length!")
        exit(-1)
    if name == "admin":
        print("invalid name!")
        exit(-1)

    ticket, nonce = gen_ticket(name)

    time.sleep(5)       # long delay due to other attackers' interception :(

    print(f"{name}'s No.{nonce} ticket is: {ticket.hex()}")

    return

def login():
    try:
        ticket = bytes.fromhex(input("your ticket (in hex): "))
        if len(ticket) < 48:
            print("login failed!")
            return

        iv, cipher, mac = ticket[:16], ticket[16:-32], ticket[-32:]

        h = hmac.HMAC(mac_key, hashes.SHA256())
        h.update(cipher)
        if h.finalize() != mac:
            print("login failed!")
            return

        aes = Cipher(algorithms.AES(enc_key), modes.CBC(iv))
        encryptor = aes.decryptor()
        data = encryptor.update(cipher) + encryptor.finalize()

        data = unpad(data)
        if not data:
            print("login failed!")
            return

        auth_data = marshal.loads(data)
        if not auth_data:
            print("login failed!")
            return

        if abs(int(auth_data["timestamp"]) - int(time.time())) >= 5:
            print("login failed!")
            return

        if auth_data["nonce"] in nonce_set:
            print("login failed!")
            return
        nonce_set.add(auth_data["nonce"])

        print(f"Welcome {auth_data['name']}...")
        if auth_data["auth_level"] == 1 and auth_data["name"] == "admin":
            print(flag)

    except:
        print("login failed!")
        return

def intercept():
    name = random.choice(["admin", "alice", "bob", "eve", "mallory", "trent"])
    ticket, nonce = gen_ticket(name)

    nonce_set.add(nonce)        # already used by that user :(

    print(f"{name}'s No.{nonce} ticket is: {ticket.hex()}")

    return


MENU = """
1. register
2. login
3. intercept
4. exit"""

def main():
    try:
        signal.alarm(60)
        if not proof_of_work():
            return
        for _ in range(0x1337):
            print(MENU)
            choice = int(input("> "))
            if choice == 1:
                register()
            elif choice == 2:
                login()
            elif choice == 3:
                intercept()
            else:
                print("Bye!")
                return
    except:
        print("Rua!")
        return

if __name__ == "__main__":
    main()